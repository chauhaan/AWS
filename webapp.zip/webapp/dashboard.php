<!DOCTYPE HTML>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/themejs.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<nav id="nav" class="navbar navbar-inverse">
				<div class="">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!--       <div class="navbar-collapse"> -->
					<ul class="nav navbar-nav navbar-collapse">
						<li >
							<a href="index.php" >Home</a>
						</li>
						<li >
							<a href="createartical.php" >Create an Artical</a>
						</li>
						<li >
							<a href="dashboard.php">Dashboard</a>
						</li>
					</ul>
					<!-- </div>  -->
					<!-- .nav-collapse -->
				</div> <!-- .container -->
			</nav> <!-- .navbar -->
		</div>
	</header>
	<div class="container">
		<div class="side-body">
			<div class="container">
				<div class="row">
					<h1>Articals Lists </h1>
					<p>Add or modify your Artical listings details.</p>
					<div class="col-md-12">
						<h2> Control Panel </h2>
						<div class="table-responsive">
							<table id="mytable" class="table table-bordred table-striped">
								<thead>
									<th>Title</th>
									<th>Description</th>
									<th>body</th>
									<th>update</th>
									<th>Delete</th>
								</thead>
								<tbody>
									<?php
									$servername = "localhost";
									$username = "root";
									$password = "root12345";
									$dbname = "blog";
// Create connection
									$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
									if ($conn->connect_error) {
										die("Connection failed: " . $conn->connect_error);
									} 

									$sql = "SELECT * FROM blg_posts";
									$result = $conn->query($sql);
									if ($result->num_rows > 0) {
		
										while($row = $result->fetch_assoc()) {
											echo "<tr>";
											echo "<td>". $row["title"]." </td>";
											echo "<td>". $row["description"]." </td>";
											echo "<td>". $row["body"]." </td>";
											echo "<td>
											<p data-placement=\"top\" data-toggle=\"tooltip\" title=\"Edit\">
											<a href=\"updateartical.php?id=".$row["id"]."\">
											<button class=\"btn btn-primary btn-xs\" data-title=\"Edit\" data-toggle=\"modal\" data-target=\"#edit\" >
											<span class=\"glyphicon glyphicon-pencil\"></span>
											</button>
											</a>
											</p></td>";
											echo "<td>
											<p data-placement=\"top\" data-toggle=\"tooltip\" title=\"Delete\">
											<a href=\"delete.php?id=".$row["id"]."\">
											<button class=\"btn btn-danger btn-xs\" data-title=\"Delete\" data-toggle=\"modal\" data-target=\"#delete\" >
											<span class=\"glyphicon glyphicon-trash\"></span>
											</button>
											</a>
											</p>
											</td>";
											echo "</tr>";
										}
									} else {
										echo "0 results";
									}
									$conn->close();
									?>  	
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>