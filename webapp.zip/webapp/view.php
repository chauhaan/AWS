<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Blog</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<nav id="nav" class="navbar navbar-inverse">
				<div class="">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!--       <div class="navbar-collapse"> -->
					<ul class="nav navbar-nav navbar-collapse">
						<li >
							<a href="index.php" >Home</a>
						</li>
						<li >
							<a href="createartical.php" >Create an Artical</a>
						</li>
						<li >
							<a href="dashboard.php">Dashboard</a>
						</li>

					</ul>
					<!-- </div>  -->
					<!-- .nav-collapse -->
				</div> <!-- .container -->
			</nav> <!-- .navbar -->
		</div>

	</header>

<div class="content">
	<div class="container">
	<h1><b>Your Blog</b></h1>

	<div class="row">
	<section >
<?php

$servername = "localhost";
$username = "root";
$password = "root12345";
$dbname = "blog";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM blg_posts where id='".$_GET["id"]."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "
        <h2><b>Title:<br>  ". $row["title"]."</b></h2>
         <br> <h4>Description: <br> ". $row["description"]. "</h4><br>
          <p>" . $row["body"] . "</p>";
        echo "<hr>";
     }
} else {
     echo "0 results";
}

$conn->close();
?>  	
	</section>
	</div>
	</div>
</div>
<footer>
	
</footer>
</body>
</html>