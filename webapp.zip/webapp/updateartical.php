<?php

?>
<!DOCTYPE HTML>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/themejs.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
		<header>
			<div class="container">
				<nav id="nav" class="navbar navbar-inverse">
					<div class="">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!--       <div class="navbar-collapse"> -->
						<ul class="nav navbar-nav navbar-collapse">
							<li >
								<a href="index.php" >Home</a>
							</li>
							<li >
								<a href="createartical.php">Create an Artical</a>
							</li>
							<li >
								<a href="dashboard.php">Dashboard</a>
							</li>

						</ul>
						<!-- </div>  -->
						<!-- .nav-collapse -->
					</div> <!-- .container -->
				</nav> <!-- .navbar -->
			</div>

		</header>
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h2>Create an Artical</h2>
					</div>
					
							<?php
									$servername = "localhost";
									$username = "root";
									$password = "root123";
									$dbname = "blog";
// Create connection
									$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
									if ($conn->connect_error) {
										die("Connection failed: " . $conn->connect_error);
									} 
									$sql = "SELECT * FROM blg_posts WHERE id='".$_GET["id"]."'";
									$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										while($row = $result->fetch_assoc()) {
											echo "<div class=\"panel-body\">";
								echo "<form action=\"update.php\" method=\"post\" role=\"form\" >";
										echo "<div class=\"form-group\">
								<input type=\"hidden\" name=\"post_id\"	value=".$_GET["id"]."\"	
								<label for=\"comment\">Title:</label>
								<textarea class=\"form-control\" name=\"title\" rows=\"1\" id=\"comment\">";
								echo $row["title"];
								echo "</textarea>
								<br>
								<label for=\"comment\">Descrption:</label>
								<textarea class=\"form-control\" name=\"des\" rows=\"4\" id=\"comment\">";
								echo $row["description"];
								echo "</textarea>
								<br>
								<label for=\"comment\">Body:</label>
								<textarea class=\"form-control\" name=\"body\" rows=\"12\" id=\"comment\">";
							echo $row["body"];
								echo "</textarea>
								<br>
								<button type=\"submit\" name=\"submit\" class=\"btn btn-default\">Submit</button>
							</div>";
										}
									} else {
										echo "0 results";
									}
									$conn->close();
									?>  	
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>


</body>
</html>