<?php

?>
<!DOCTYPE HTML>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/themejs.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
		<header>
			<div class="container">
				<nav id="nav" class="navbar navbar-inverse">
					<div class="">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!--       <div class="navbar-collapse"> -->
						<ul class="nav navbar-nav navbar-collapse">
							<li >
								<a href="index.php" >Home</a>
							</li>
							<li >
								<a href="createartical.php">Create an Artical</a>
							</li>
							<li >
								<a href="dashboard.php">Dashboard</a>
							</li>

						</ul>
						<!-- </div>  -->
						<!-- .nav-collapse -->
					</div> <!-- .container -->
				</nav> <!-- .navbar -->
			</div>

		</header>
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h2>Create an Artical</h2>
					</div>
					<div class="panel-body">
						<form action="create.php" method="post" role="form" >
							<div class="form-group">
								<label for="comment">Title:</label>
								<textarea class="form-control" name="title" rows="1" id="comment"></textarea>
								<br>
								<label for="comment">Descrption:</label>
								<textarea class="form-control" name="des" rows="2" id="comment"></textarea>
								<br>
								<label for="comment">Body:</label>
								<textarea class="form-control" name="body" rows="12" id="comment"></textarea>
								<br>
								<button type="submit" name="submit" class="btn btn-default">Submit</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>


</body>
</html>