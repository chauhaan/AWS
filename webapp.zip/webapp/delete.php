<?php
$servername = "localhost";
$username = "root";
$password = "root123";
$dbname = "blog";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM blg_posts WHERE id='".$_GET["id"]."'";

if ($conn->query($sql) === TRUE) {
	echo "<script>window.location=\"dashboard.php\"</script>";

} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>