<?php

$servername = "localhost";
$username = "root";
$password = "root123";
$dbname = "blog";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `blg_posts` (`title`,`description`,`body`) VALUES (
	'".$_POST["title"]."',
	'".$_POST["des"]."',
	'".$_POST["body"]."')";

if ($conn->query($sql) === TRUE) {
	echo "<script>window.location=\"index.php\"</script>";
   
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>