<?php

$servername = "localhost";
$username = "root";
$password = "root123";
$dbname = "blog";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "UPDATE blg_posts SET title='".$_POST["title"]."',
 description='".$_POST["des"]."' ,
 body='".$_POST["body"]."'
  WHERE id='".$_POST["post_id"]."'";

if ($conn->query($sql) === TRUE) {
	echo "<script>window.location=\"dashboard.php\"</script>";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

?>