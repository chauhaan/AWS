<?php 
session_start();
?>

<!DOCTYPE HTML>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>
<div class="container">
		<header>
		<div class="container">
			<nav id="nav" class="navbar navbar-inverse">
				<div class="">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!--       <div class="navbar-collapse"> -->
					<ul class="nav navbar-nav navbar-collapse">
						<li >
							<a href="index.php" >Front End</a>
						</li>
						<li >
							<a href="login.php" >Backend</a>
						</li>
					</ul>
					<!-- </div>  -->
					<!-- .nav-collapse -->
				</div> <!-- .container -->
			</nav> <!-- .navbar -->
		</div>

	</header>
	<div class="wrapper">
		<form action="loginit.php" method="post" name="Login_Form" class="form-signin">       
		    <h3 class="form-signin-heading">Welcome Back! Please Sign In</h3>
			  <hr class="colorgraph"><br>
			  
			  <input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="" />
			  <input type="password" class="form-control" name="password" placeholder="Password" required=""/>     		  
			 
			  <button class="btn btn-lg btn-primary btn-block"  name="submit" value="Login" type="Submit">Login</button>  			
		</form>			
	</div>
</div>
</body>
</html>