<?php
$servername = "localhost";
$username = "root";
$password = "root123";
$dbname = "blog";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `users` WHERE username='".$_POST["username"]."'";

$result = $conn->query($sql);

if ($row = mysqli_fetch_array($result)){
	if (($_POST["password"]==$row['password'])){

	echo "<script>window.location=\"dashboard.php\"</script>";
	}
	
} else { 

   echo "<script>window.location=\"login.php\"</script>";
}
$conn->close();
?>